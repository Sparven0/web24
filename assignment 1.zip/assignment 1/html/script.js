function rekna(){

    let num1 = document.getElementById('inputOne').value;
    let num2 = document.getElementById('inputTwo').value;
    let produkt = document.getElementById('calculate').value;

    if(calculate ==='+'){
        let num1 = parseInt (document.getElementById('inputOne').value);
    let num2 = parseInt (document.getElementById('inputTwo').value);
    document.getElementById('produkt').value=num1+num2;

    if(calculate ==='-'){
        let num1 = parseInt (document.getElementById('inputOne').value);
    let num2 = parseInt (document.getElementById('inputTwo').value);
    document.getElementById('produkt').value=num1-num2;


    if(calculate ==='*'){
        let num1 = parseInt (document.getElementById('inputOne').value);
    let num2 = parseInt (document.getElementById('inputTwo').value);
    document.getElementById('produkt').value=num1*num2;


    if(calculate ==='/'){
        let num1 = parseInt (document.getElementById('inputOne').value);
    let num2 = parseInt (document.getElementById('inputTwo').value);
    document.getElementById('produkt').value=num1/num2;


    
     }
    }
   }
  }
} 